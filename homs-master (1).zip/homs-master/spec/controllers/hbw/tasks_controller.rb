describe HBW::TasksController, type: :controller do
  describe 'Get' do
    it 'tasks list' do
    end
  end
end
